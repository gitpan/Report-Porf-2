perl demo.pl 11 text hash example_hash.pl > result_hash_11.txt
perl demo.pl 12 text hash minimal_hash.pl
perl demo.pl 13 text hash short_hash.pl > result_short_hash_13.txt

perl demo.pl 14 text array example_array.pl > result_array_14.txt
perl demo.pl 15 text array minimal_array.pl
perl demo.pl 16 text array short_array.pl > result_short_array_16.txt

perl demo.pl 17 text object example_object.pl > result_object_14.txt
perl demo.pl 18 text object minimal_object.pl
perl demo.pl 19 text object short_object.pl > result_short_object_16.txt

perl demo.pl 11 html hash example_hash.pl > result_hash_11.html
perl demo.pl 12 html hash minimal_hash.pl
perl demo.pl 13 html hash short_hash.pl > result_short_hash_13.html

perl demo.pl 14 html array example_array.pl > result_array_14.html
perl demo.pl 15 html array minimal_array.pl
perl demo.pl 16 html array short_array.pl > result_short_array_16.html

perl demo.pl 17 html object example_object.pl > result_object_17.html
perl demo.pl 18 html object minimal_object.pl
perl demo.pl 19 html object short_object.pl > result_short_object_19.html

perl demo.pl 11 csv hash example_hash.pl > result_hash_11.csv
perl demo.pl 12 csv hash minimal_hash.pl
perl demo.pl 13 csv hash short_hash.pl > result_short_hash_13.csv

perl demo.pl 14 csv array example_array.pl > result_array_14.csv
perl demo.pl 15 csv array minimal_array.pl
perl demo.pl 16 csv array short_array.pl > result_short_array_16.csv
